insert into fwworlddevdb.genhints(Label,StringID) values(9999,32050);
insert into fwworlddevdb.genhints(Label,StringID) values(9999,32051);
insert into fwworlddevdb.genhints(Label,StringID) values(9999,32052);